﻿=== Customized Linux Fedora Core 5 Cursor Set ===

By: flarcin02

Download: http://www.rw-designer.com/cursor-set/customized-linux-fedora-core-5

Author's description:

I costomized the Linux Fedora 5 Cursors for you, enjoy it. ;)

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.